export class Ingredients {
  constructor(public name: string, public amount: number) {}
}
