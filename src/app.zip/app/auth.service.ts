import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user;
  constructor(
    private angularFireAuth: AngularFireAuth,
    private router: Router
  ) {
    this.angularFireAuth.authState.subscribe((user) => {
      if (user) {
        this.user = user;
        localStorage.setItem('user', JSON.stringify(user));
      } else {
        this.user = null;
        localStorage.removeItem('user');
      }
    });
  }
  get isLoggedIn(): boolean {
    const user = JSON.parse(localStorage.getItem('user'));
    return user != null;
  }
  login(email: string, password: string) {
    return this.angularFireAuth
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        this.angularFireAuth.authState.subscribe((user) => {
          if (user) {
            localStorage.setItem('user', JSON.stringify(user));
            this.router.navigate(['/recipes']);
          }
        });
      });
  }

  logOut() {
    this.angularFireAuth.signOut().then(() => {
      localStorage.clear();
      this.user = null;
      this.router.navigate(['/auth']);
    });
  }

  signUp(email: string, password: string) {
    this.angularFireAuth
      .createUserWithEmailAndPassword(email, password)
      .then((user) => {
        localStorage.setItem('user', JSON.stringify(user));
        this.router.navigate(['/recipes']);
      });
  }
}
